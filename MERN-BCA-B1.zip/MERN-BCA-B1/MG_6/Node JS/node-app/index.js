

const http = require('http');
const dotenv = require('dotenv');
const path = require('path');
const express = require('express');
const app = express();
dotenv.config();
require('./config/database')();
const PORT = process.env.PORT || 8080;

const router  = require('./routes/api-route');


let server = http.createServer(app);

app.use(express.static(path.join(__dirname, 'public')));


app.use('/api',router.route);




server.listen(PORT, function(err){
  if(err) throw err;
  console.log(`Server is running on port ${PORT}`);
 
});


