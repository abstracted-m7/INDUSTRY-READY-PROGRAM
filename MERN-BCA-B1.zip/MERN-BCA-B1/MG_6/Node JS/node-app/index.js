

const http = require('http');
const dotenv = require('dotenv');
const path = require('path');
const express = require('express');
const bodyParser = require("body-parser");
const app = express();
dotenv.config();
const PORT = process.env.PORT || 8080;
const router  = require('./routes/api-route');

require('./config/database')();


let server = http.createServer(app);

app.use(express.static(path.join(__dirname, 'public')));



app.use(bodyParser.json());


app.use('/api',router.route);


server.listen(PORT, function(err){
  if(err) throw err;
  console.log(`Server is running on port ${PORT}`);
 
});