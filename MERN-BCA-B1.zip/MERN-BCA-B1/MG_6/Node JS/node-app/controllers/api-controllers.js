
class apiController {
    getUser = (req , res ) => {
        res.send({
            message: "User retrieved successfully",
            user: {
                name: "Manish Giri",
                age: 20,
                email: "abc8101@example.com"
            }
        });
    }
    getStudent = (req , res ) => {
        res.send({
            message: "Student Details",
            user: [{
                name: "Manish Giri",
                age: 20,
                dept: "BCA"
            },
            {
                name: "Suman Bajani",
                age: 20,
                dept: "BCA"
            },
            {
                name: "Manish Giri",
                age: 20,
                dept: "BCA"
            }]

        });
    }
    
}

module.exports = new apiController();