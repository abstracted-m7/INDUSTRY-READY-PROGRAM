

const userModel = require('../model/user-model');


class apiController {
    getUser = async(req , res) => {

        try{
        
        // Fetch only one user from the database
        let userSinglweData = await userModel.findOne();
        console.log(userSinglweData,'userSinglweData');

        //Data Facted using conditions
        let withQuary = await userModel.findOne({active_status : true , delete_status : false});

        console.log(withQuary,'withQuary');


        // Send the response with the fetched data
        res.send({
            'message': 'Total data in the database :',
            data : withQuary
        });

        } 
        
        // For Handle error
        catch(err){
            res.send({
                "message": "Error in getting user...",
                "error": err.message
            });
        }
    
    }

    // For edit user details
    editUser = async(req , res) => {
        console.log(req.body, '=+++');
        res.send({
            "message": 'Edit Data',
            data: req.body
        });
    }


    // For inserting a new user in the database
    addUser = async(req, res) => {
        try{
            //for encripted overlapping
            console.log(req.body,"req.body");
            let User = new userModel();
            
            //for encripted password
            req.body.password = User.generateHash(req.body.password);

            //for encripted phone number
            req.body.phone = User.generateHash(req.body.phone);

            // Create a new user
            let newUser = new userModel(req.body);

            // Save the user to the database
            await newUser.save();
            
            // Send the response with the saved data
            res.send({
                "message": 'Data added successfully...',
                data: newUser
            });
        }
        catch(err){
            console.log(err)
            res.send({
                "message": "Error in inserting new user...",
                "error": err
            });
        }
    
    }

    getSingleData = async(req, res)=> {
        try{

            //type one
            // let userSingleData = await userModel.findById(req.params.id);
            
            //type two
            // let userSingleData = await userModel.findOne({_id: req.params.id});

            //find by age
            // let userSingleData = await userModel.findOne({age : 19});
            
            //find by email
            let userSingleData = await userModel.findOne({email : 'ayan121@gmail.com'});

            res.send({
                "message": 'Single data retrive successfully...',
                data : userSingleData
            })
            console.log(userSingleData);
            
        } catch(err){
            res.send({
                "message": "Error in retrive single data...",
                "error": err
            });
        }
    }

    updateData = async(req, res)=> {
        try{

            //update single data
            // let userUpdateData = await userModel.findOne({age : 19});
            // userUpdateData.age = 20;
            // await userUpdateData.save();

            // // update full data
            // let userUpdateData = await userModel.findByIdAndUpdate(req.body.id, req.body);

            // update directly
            let updateDirect = await userModel.findOne({name : "Ayan Bhowmick"});
            updateDirect.name = "Ayan Dadu";
            await updateDirect.save();

            res.send({
                "message": 'Data updated successfully...',
                data : updateDirect
            })
            console.log(updateDirect);
            
        } catch(err){
            res.send({
                "message": "Error in updating data...",
                "error": err
            });
        }
    }
    
    deleteData = async(req, res)=> {
        try{

            let userSingleData = await userModel.findOne({_id: req.param.id , delete_status: false});

            if(userSingleData){
                    // soft delete
                    let softDataDelete = await userModel.findByIdAndUpdate(req.params.id, {delete_status : true});

                    // hard delete
                    let hardDataDelete = await userModel.findByIdAndDelete(req.params.id);

                    res.send({
                        "message": 'Data deleted successfully...',
                        data : hardDataDelete
                    })
                    console.log(hardDataDelete);
                }
                else{
                    res.send({
                        "message": 'Data not found...',
                        data : null
                    })
                }
            
        } catch(err){
            res.send({
                "message": "Error in deleting data...",
                "error": err
            });
        
        }
    }
}

module.exports = new apiController();