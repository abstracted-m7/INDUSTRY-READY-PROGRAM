

const UserModel = require('../model/user-model');


class apiController {
    getUser = async(req , res) => {

        let UserData = await UserModel.find();

        console.log(UserData,'UserData');

        res.send({
            'message': 'Hlw user',
            "data": UserData
        });

    } 
    
}

module.exports = new apiController();