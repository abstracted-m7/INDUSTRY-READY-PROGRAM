

const userModel = require('../model/user-model');


class apiController {
    getUser = async(req , res) => {

        try{
        
        // Fetch only one user from the database
        let userSinglweData = await userModel.findOne();
        console.log(userSinglweData,'userSinglweData');

        //Data Facted using conditions
        let withQuary = await userModel.findOne({active_status : true , delete_status : false});

        console.log(withQuary,'withQuary');


        // Send the response with the fetched data
        res.send({
            'message': 'Total data in the database :',
            data : withQuary
        });

        } 
        
        // For Handle error
        catch(err){
            res.send({
                "message": "Error in getting user...",
                "error": err.message
            });
        }
    
    }

    // For edit user details
    editUser = async(req , res) => {
        console.log(req.body, '=+++');
        res.send({
            "message": 'Edit Data',
            data: req.body
        });
    }


    // For inserting a new user in the database
    addUser = async(req, res) => {
        try{
            //for encripted overlapping
            console.log(req.body,"req.body");
            let User = new userModel();
            req.body.password = User.generateHash(req.body.password);

            // Create a new user
            let newUser = new userModel(req.body);

            // Save the user to the database
            await newUser.save();
            
            // Send the response with the saved data
            res.send({
                "message": 'Data added successfully...',
                data: newUser
            });
        }
        catch(err){
            console.log(err)
            res.send({
                "message": "Error in inserting new user...",
                "error": err
            });
        }
    
    }
}

module.exports = new apiController();