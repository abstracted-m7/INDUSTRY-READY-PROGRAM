
const mongoose = require('mongoose');

module.exports = () => {
    try {
        mongoose.connect(process.env.mongodb_URL);
        console.log("MongoDB Connected..");
    } catch (err) {
        console.log("Failed to connect to MongoDB", err);
    }
}

