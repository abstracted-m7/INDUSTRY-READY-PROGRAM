

const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const Schema =  mongoose.Schema;
const saltRounds = 10;

const UserModel = new Schema({
    name: {type: String},
    email: {type: String},
    password: {type: String},
    phone: {type: String},
    age: {type: Number},

    // always active status is true
    active_status: { 
        type: Boolean,
        default:true,
        enum:[true, false]
    },

    // always delete status is false means user cant see the data from database
    delete_status: { 
        type: Boolean,
        default: false,
        enum:[true, false]
    },
},
 // for automatic record of created and modified date and time
{timestamps : true , versionKey : false});


// // for password encripted user's password
UserModel.methods.generateHash = function(password){
    return bcrypt.hashSync(password, saltRounds , null);
};

// for phone number encripted
UserModel.methods.generateHash = function(phone){
    return bcrypt.hashSync(phone, saltRounds , null);
}


module.exports = mongoose.model('users', UserModel);