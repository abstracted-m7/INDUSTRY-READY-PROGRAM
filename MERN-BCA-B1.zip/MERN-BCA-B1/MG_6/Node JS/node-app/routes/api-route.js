const express = require('express');

const router = express.Router();

const ApiController = require('../controllers/api-controllers');



router.get('/user/list',ApiController.getUser);

router.post('/user/edit',ApiController.editUser);

router.post('/user/add',ApiController.addUser);

router.get('/user/info/:id',ApiController.getSingleData);

router.get('/user/update',ApiController.updateData);

router.get('/user/delete/:id',ApiController.deleteData);






// router.get('/user/create', ApiController.gethtml);

module.exports = {
    route: router
}