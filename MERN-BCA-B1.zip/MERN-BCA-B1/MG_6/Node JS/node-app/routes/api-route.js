const express = require('express');

const router = express.Router();

const ApiController = require('../controllers/api-controllers');


// router.get('/user', function (req, res) {
//     res.send('Welcome..!!  This is User Section :)');
// });


// router.get('/user/login', function (req, res) {
//     res.send('User created successfully..!!');
// });

// router.get('/user/list',ApiController.getStudent);
router.get('/user/list',ApiController.getUser);


// router.get('/user/create', ApiController.gethtml);

module.exports = {
    route: router
}